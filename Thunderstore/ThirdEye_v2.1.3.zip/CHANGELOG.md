> # Update Information (Latest listed first)
> ### v2.1.3
> - Updated for Valheim 0.216.5
> - Filter out tames option.
> ### v2.0.3
> - Mistlands update
> ### v2.0.1/2.0.2
> - Update ServerSync internally
> ### v2.0.0
> - Update ServerSync and SkillManager internally
> - Changed the config file name to be more consistent with my other mods. (Azumatt.ThirdEye.cfg)
> ### v1.0.0
> - Initial Release